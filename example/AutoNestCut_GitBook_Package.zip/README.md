# AutoNestCut Documentation

Welcome to the AutoNestCut documentation. This multi-page GitBook-style documentation is split into focused sections so readers can quickly find what they need.

Quick notes before uploading to GitBook:

- IMAGE_BASE placeholder: replace `{{IMAGE_BASE}}` with your media repository base URL (for example `https://media.example.com/mike-ai-lab/cutlist`) when you publish to GitBook. The pages include a fallback to local images in `example/` if the remote images are not available.
- Upload the `example/` images (already present in the repo) to your GitBook media library or CDN and set IMAGE_BASE accordingly.

Start with the Getting Started page listed in the sidebar.
